#language C++Script

#include "GlobalScripts.pas", "Global.pas"
//==================================
void HideMsg()
{
	Screen1.pnlMsg.Visible = false;
}

//==================================
{
}