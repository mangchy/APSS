#language C++Script

#include "GlobalScripts.pas", "Global.pas"
//==================================
void UpdateUI()
{
  Screen1.dhProgress1.UserValue = gDownloadedCount;
}

//==================================
{
}