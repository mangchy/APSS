#language C++Script

#include "GlobalScripts.pas", "Global.pas", "InitCallBackFromVB.cpp"
//==================================
void ResKResponse()
{
    SetKResponse();
}

//==================================
{
}