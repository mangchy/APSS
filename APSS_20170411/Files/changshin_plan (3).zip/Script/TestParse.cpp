#language C++Script

#include "GlobalScripts.pas", "Global.pas", "InitCallBackFromVB.cpp"
//==================================
void TestParse()
{
  ParseAData(Screen1_1.dhEdit3.Text);//"A0400000231115032103414 4  84819416600221 2 2 84 410580003<>5");
}

//==================================
{
}