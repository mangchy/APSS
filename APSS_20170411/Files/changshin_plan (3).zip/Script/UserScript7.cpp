#language C++Script

#include "GlobalScripts.pas", "Global.pas"
//==================================
void UserScript7()
{
  Screen1.dhProgress1.MaxValue = gOrderCount;
}

//==================================
{
}