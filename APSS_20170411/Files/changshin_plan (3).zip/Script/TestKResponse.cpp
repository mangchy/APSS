#language C++Script

#include "GlobalScripts.pas"
//==================================
void TestKResponse()
{
    SetTagValue(Tag1, "1234");
}

//==================================
{
}