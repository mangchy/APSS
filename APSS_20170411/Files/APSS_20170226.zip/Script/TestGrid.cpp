#language C++Script

#include "GlobalScripts.pas", "dg.cpp"
//==================================
void TestGrid()
{
    dataGrid("1-L","MS247700-1 8T","IU001 BLUE","25 06:00:00",
                "25 14:32:00","48","48","2","2","#1","25 06:00:00","25 14:53:00","");
//    int row = frmScreen1.dhGrid1.SetAddRow;
//    frmScreen1.dhGrid1.SetCelldataColor2(row, 0, "1-L", false, 0x00009393, clBlack);//
//    frmScreen1.dhGrid1.SetCelldataColor2(row, 1, "MS247700-1 8T", false, 0x00009393, clBlack);
//    frmScreen1.dhGrid1.SetCelldataColor2(row, 2, "IU001 BLUE", false, 0x00009393, clBlack);
//    frmScreen1.dhGrid1.SetCelldataColor2(row, 3, "25 06:00:00", false, 0x00009393, clBlack);
//    frmScreen1.dhGrid1.SetCelldataColor2(row, 4, "25 14:32:00", false, 0x00009393, clBlack);
//    frmScreen1.dhGrid1.SetCelldataColor2(row, 5, "48", false, 0x00FFAF60, clBlack);
//    frmScreen1.dhGrid1.SetCelldataColor2(row, 6, "48", false, clWhite, clBlack);//clWhite);
//    frmScreen1.dhGrid1.SetCelldataColor2(row, 7, "2", false, clWhite, clBlack);//clWhite);
//    frmScreen1.dhGrid1.SetCelldataColor2(row, 8, "2", false, clWhite, clBlack);//clWhite);
//    frmScreen1.dhGrid1.SetCelldataColor2(row, 9, "#1", false, 0x00FFAF60, clBlack);
//    frmScreen1.dhGrid1.SetCelldataColor2(row, 10, "25 06:00:00", false, clWhite, clBlack);//clWhite);
//    frmScreen1.dhGrid1.SetCelldataColor2(row, 11, "25 14:53:00", true, clWhite, clBlack);//clWhite);
//    frmScreen1.dhGrid1.LastRow();
}

//==================================
{
}