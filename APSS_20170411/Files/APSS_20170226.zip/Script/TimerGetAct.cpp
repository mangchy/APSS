#language C++Script

#include "GlobalScripts.pas"
//==================================
void TimerGetActual()
{
    GetTagValueI(TagMoldRAct1);
}

//==================================
{
}