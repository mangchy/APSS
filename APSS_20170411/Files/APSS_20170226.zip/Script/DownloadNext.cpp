#language C++Script
#include "GlobalScripts.pas", "LPComm.cpp"

void DownloadNext()
{
	
	showMessage("next");
}

{
}