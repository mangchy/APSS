#language C++Script

#include "GlobalScripts.pas"
//==================================
void UpdateDateTime()
{
   //frmScreen1.txtDate.Text = FormatDateTime("YYYYMMDD", Now());
   frmScreen1.lbTime.Caption = "Time : " + FormatDateTime("DD HH:NN:SS", Now());
   
   if(frmScreen1_4.cbxNowTime.Checked)
   {
        frmScreen1_4.edtHour.Text = FormatDateTime("HH", Now());
        frmScreen1_4.edtMin.Text  = FormatDateTime("NN", Now());
   }
}

//==================================
{
}