#language C++Script

#include "GlobalScripts.pas"
//==================================
void ReadBarcode()
{
    if(frmScreen1_4.pnlBarcode.Caption != GetTagValueS(TagBarcode))
    {
        frmScreen1_4.lbReadTime.Caption = DateTimeToStr(Now);
        frmScreen1_4.pnlBarcode.Caption = GetTagValueS(TagBarcode);
    }
}

//==================================
{
}