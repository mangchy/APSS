#language C++Script

#include "GlobalScripts.pas"
//==================================
void ClearDebugMessage()
{
    frmScreen1_3.dhGrid1.Clear();
}

//==================================
{
}