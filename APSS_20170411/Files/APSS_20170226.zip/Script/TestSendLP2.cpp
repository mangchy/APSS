#language C++Script

#include "GlobalScripts.pas", "LPComm.cpp"
//==================================
void TestSendLP2()
{
    //tagAddr, istation, iside, moldsize, moldcolor, shift, inor_plncnt, inor_plncnt-inor_actcnt, iosd_plncnt, iosd_plncnt-iosd_actcnt, vso_id
    //LP_SendData(WS2, istation, iside, moldsize, moldcolor, shift, inor_plncnt, inor_plncnt-inor_actcnt, iosd_plncnt, iosd_plncnt-iosd_actcnt, vso_id);
}

//==================================
{
}