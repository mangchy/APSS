#language C++Script

#include "GlobalScripts.pas", "GlobalJJ.cpp"



//========================================================================================
void TimerGetActual()
{     
	if(gLPSOIDZeroNum > 0) 
	{
		gLPSOIDZeroNum = UpdateSOID();
		
		SetDebug(Format("number of zero SOID : %d", [gLPSOIDZeroNum]));
	}
	
	/*
	for(int i=0; i<ALL_ORDERS; i++)
    {
        gDownloadData[i] = -1;
    }*/

	for(i=0; i<STATION_NUM; i++)
    {
		if(gWorkingRow[i] == -1) continue;

		TDateTime dt1 = GetTagUpdateTime(gTagNorA[i]);
		TDateTime dt2 = GetTagUpdateTime(gTagOsdA[i]);
		TDateTime dt3 = GetTagUpdateTime(gTagOsdP[i]);
		
		if(dt1 == gTagUpdateTime1[i]) continue;
		if(dt2 == gTagUpdateTime2[i]) continue;
		if(dt3 == gTagUpdateTime3[i]) continue;

		gTagUpdateTime1[i] = dt1;
		gTagUpdateTime2[i] = dt2;
		gTagUpdateTime3[i] = dt3;
		
		int iAct = GetTagValueI(gTagNorA[i]);//LP Data, down count
        int iOSD = GetTagValueI(gTagOsdA[i]);   
		int iOSDPln = GetTagValueI(gTagOsdP[i]);
		
		int iDBnor_actcnt = gWorkingNormalPln[i] - gWorkingNormal[i];
		int iDBosd_actcnt = gWorkingOSnDPln[i]   - gWorkingOSnD[i];
		
		//frmScreen1.dhGrid1.SetCellData(gWorkingRow[i], 4, FormatDateTime("HH:NN:SS", dt1), false);//IntToStr(iDBnor_actcnt), true);	
		frmScreen1.dhGrid1.SetCellData(gWorkingRow[i], COLUMN_NORACTCNT, IntToStr(gWorkingNormalPln[i] - iAct), true);	
		//frmScreen1.dhGrid1.SetCellData(gWorkingRow[i], COLUMN_OSNDPLNCNT, IntToStr(iDBosd_actcnt), true);	
		
		//frmScreen1.dhGrid1.SetCellData(gWorkingRow[i], COLUMN_NORACTCNT, Format("%d, %d < %d", [gWorkingNormalPln[i], iAct, iDBnor_actcnt]), false);//IntToStr(iDBnor_actcnt), true);	
		//frmScreen1.dhGrid1.SetCellData(gWorkingRow[i], COLUMN_OSNDPLNCNT, Format("%d, %d < %d", [gWorkingOSnDPln[i], iOSDPln, iDBosd_actcnt]), true);//IntToStr(iDBosd_actcnt), true);	
		
		//continue;
		//SetDebug(Format("get actual data : %d, %d, (%d ? %d)", [gWorkingRow[i], gWorkingNormalPln[i], iAct, iDBnor_actcnt]));
		if(iAct < iDBnor_actcnt)//normal count
		{
			//ShowMessage(Format("normal, %d, %d, %d, %d, %d", [i, gWorkingRow[i], iDBnor_actcnt, iAct,  gWorkingNormal[i], gWorkingNormalPln[i]]));
			gWorkingNormal[i] = gWorkingNormalPln[i] - iAct;
			frmScreen1.dhGrid1.SetCellData(gWorkingRow[i], COLUMN_NORACTCNT, IntToStr(gWorkingNormal[i]), true);	
			
			InsertWorkCountToDB(gWorkingSOID[i], gWorkingNormalPln[i], iDBnor_actcnt - iAct, gZone, "00");

			if(checkFinish(gWorkingRow[i], i, iAct, iOSD) == 1) return;
		}
		else if(iDBosd_actcnt < iOSD)//os&d count
		{
			gWorkingOSnD[i] = gWorkingOSnDPln[i] - iOSD;
			frmScreen1.dhGrid1.SetCellData(gWorkingRow[i], COLUMN_NORACTCNT, IntToStr(gWorkingNormal[i]), true);	
			//ShowMessage(Format("os&d, %d, %d, %d, %d, %d", [i, gWorkingRow[i], iDBosd_actcnt, iOSD,  gWorkingOSnDPln[i]]));

			InsertWorkCountToDB(gWorkingSOID[i], gWorkingNormalPln[i], gWorkingOSnD[i], gZone, "01");

			if(checkFinish(gWorkingRow[i], i, iAct, iOSD) == 1) return;
		}

		if(gWorkingOSnDPln[i] < iOSDPln)//update (OS&D Plan) of DATA_SO
		{
			//gWorkingOSnD[i] = iOSD;
			frmScreen1.dhGrid1.SetCellData(gWorkingRow[i], COLUMN_OSNDPLNCNT, IntToStr(iOSDPln), true);	
			UpdateOSnDPlnToDB(gWorkingSOID[i], iOSDPln);
		}
	}
}

//==================================
{
}