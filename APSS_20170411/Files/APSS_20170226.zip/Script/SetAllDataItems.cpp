#language C++Script

#include "GlobalScripts.pas"
//==================================
void SetAllDataItems()
{
	frmScreen1_4.cbxNPCnt.Checked = frmScreen1_4.cbxAllItems.Checked;
	frmScreen1_4.cbxNACnt.Checked = frmScreen1_4.cbxAllItems.Checked;
	frmScreen1_4.cbxOPCnt.Checked = frmScreen1_4.cbxAllItems.Checked;
	frmScreen1_4.cbxOACnt.Checked = frmScreen1_4.cbxAllItems.Checked;
	frmScreen1_4.cbxSOID.Checked = frmScreen1_4.cbxAllItems.Checked;
	//frmScreen1_4.cbxMold.Checked = frmScreen1_4.cbxAllItems.Checked;
	//frmScreen1_4.cbxMoldColor.Checked = frmScreen1_4.cbxAllItems.Checked;
}

//==================================
{
}