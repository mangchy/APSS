#language C++Script

#include "GlobalScripts.pas"
//==================================
void SetMachineTag()
{

}

//==================================
{
}