#language C++Script

#include "GlobalScripts.pas"
//==================================
void OnTimerAllClear2()
{
    //LP_SendData
}

//==================================
{
}