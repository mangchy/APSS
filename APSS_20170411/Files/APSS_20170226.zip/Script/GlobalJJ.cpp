#include "GlobalScripts.pas", "JJUtils.cpp"

string gSvr_type = ""; //"SQL SERVER";
string gSvr 	 = ""; //"(local)";
string gPort 	 = ""; //"1433";
string gUid 	 = ""; //"sa";
string gPwd 	 = ""; //"system" ;
string gDbname 	 = ""; //"IP_SS";
string gZone 	 = ""; //"Z001";


#define ALL_STATION  	24		//STATION 8 X 3 SET
#define ALL_ORDERS 	 	48		//EATCH STATION PAIR (L, R)

#define LP_NUM			2
//#define STATION
#define STATION_NUM 	16		//LP 2ea ....test(L, R)


int 		gDownloadNum;
int 		gDownloadedIdx;
int 		gDownloadData[ALL_ORDERS];
Variant 	gSO_ID[ALL_ORDERS];
    

int 		gLActCnt[ALL_STATION];
int 		gLPlnCnt[ALL_STATION];
int 		gRActCnt[ALL_STATION];
int 		gRPlnCnt[ALL_STATION];

int			gWorkingRow[ALL_ORDERS];//1L,R,2L,R,......
int			gWorkingNormalPln[ALL_ORDERS];//1L,R,2L,R,......
int			gWorkingNormal[ALL_ORDERS];//1L,R,2L,R,......
int			gWorkingOSnDPln[ALL_ORDERS];//1L,R,2L,R,......
int			gWorkingOSnD[ALL_ORDERS];//1L,R,2L,R,......
int			gWorkingSOID[ALL_ORDERS];//

int			gCurrentStation;
int			gCurrentSortKey;

int			gQueryWithCompleted = 0;

//GRID COLUMN
#define COLUMN_MOLDSIZE		1
#define COLUMN_MOLDCOLOR	2
#define COLUMN_NORPLNCNT	5
#define COLUMN_NORACTCNT	6
#define COLUMN_OSNDPLNCNT	7
#define COLUMN_OSNDACTCNT	8
#define	COLUMN_SORT_KEY		13
#define	COLUMN_SHOESSIDE	14
#define	COLUMN_STATION		15
#define	COLUMN_SO_ID		17
#define	COLUMN_COLOR		18
#define	COLUMN_MACHINE		19


#define COLOR_WORK_FINISH		clLime
#define COLOR_WORK_PROGRESS		clYellow
#define COLOR_WORK_NEXT			clAqua

int 		gTagNorP[ALL_ORDERS];
int 		gTagNorA[ALL_ORDERS];
int 		gTagOsdP[ALL_ORDERS];
int 		gTagOsdA[ALL_ORDERS];
int 		gTagSOID[ALL_ORDERS];
int 		gTagMold[ALL_ORDERS];
int 		gTagColor[ALL_ORDERS];
int 		gTagTimeWrite[ALL_ORDERS];

int			gTagWrite[6];//LP 2 * 3


int			gLPSOIDZeroNum;

TDateTime	gTagUpdateTime1[ALL_ORDERS];
TDateTime	gTagUpdateTime2[ALL_ORDERS];
TDateTime	gTagUpdateTime3[ALL_ORDERS];

//=======================================================================================
void SetUpdaeTagTime()
{
	for(int i=0; i<STATION_NUM; i++)
	{
		gTagUpdateTime1[i] = GetTagUpdateTime(gTagNorA[i]);
        gTagUpdateTime2[i] = GetTagUpdateTime(gTagOsdA[i]);   
		gTagUpdateTime3[i] = GetTagUpdateTime(gTagOsdP[i]);
	}
}

//=======================================================================================
void SetDebug(String message, TColor aTextColor=clBlack)
{
	int iDebugRow = frmScreen1_3.dhGrid1.SetAddRow(false);
	frmScreen1_3.dhGrid1.SetCellData(iDebugRow, 0, DateTimeToStr(Now), false);
	frmScreen1_3.dhGrid1.SetCellDataColor(iDebugRow, 1, message, true, aTextColor);//Format("soid not found : %d, %d", [i,iSOID]), true);
	frmScreen1_3.dhGrid1.LastRow;
}

//=======================================================================================
int getMachineIndex(String aMc)
{
	//ShowMessage(Format("%d, %s", [frmScreen1.cbxMC.Items.Count, aMc]));
	for(int i=1; i<frmScreen1.cbxMC.Items.Count; i++)
	{
		if(frmScreen1.cbxMC.Items.Strings[i] == aMC) return i-1;//1 --> all machine
	}
	
	return -1;
}

//=======================================================================================
int getGridRowFromSOID(String tarMachine, int aOrderPos, int aSOID)
{
	//string s1 = "";
	//for(int i=1; i<frmScreen1.cbxMC.Items.Count; i++)
//	{
	//	s1 += frmScreen1.cbxMC.Items.Strings[i] + ", ";// == aMC) return i-1;//1 --> all machine
	//}
	//ShowMessage(s1);
	
	
	int row_cnt = frmScreen1.dhGrid1.GetRowCount;
	for(int grid_row=0; grid_row<row_cnt; grid_row++)
	{		
		String so_id = frmScreen1.dhGrid1.GetCellData(grid_row, COLUMN_SO_ID);	
		String machine  = frmScreen1.dhGrid1.GetCellData(grid_row, COLUMN_MACHINE);
	
		//int dbMCIndex = getMachineIndex(machine);
		//int targetMCIndex = Int(aOrderPos/16);//16 --> 1 mca = 2LP, 1LP=8 order   each machine have two LP,
		//if(dbMCIndex == targetMCIndex)
		if(machine == tarMachine)
		{
//ShowMessage(s1 + machine + ", " + IntToStr(dbMCIndex));	
			if(aSOID == StrToIntDef(so_id, -1)) return grid_row;
		}
	}
	SetDebug(Format("not found soid : %d, %d", [aOrderPos, aSOID]), clRed);
	return -1;
}


//=======================================================================================
int getGridRow(String tarMachine, int aOrderPos)
{
	int imin_sort_key = 999999999;
	int row_cnt2 = frmScreen1.dhGrid1.GetRowCount;
	int row_result = -1;
	for(int grid_row2=0; grid_row2<row_cnt2; grid_row2++)
	{
		String station  = frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_STATION);	
		String machine  = frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_MACHINE);	
		
		int istation    = StrToInt(station) - 1;//db sation ... 01, 02, 03 ....
		int aGridStation = Int(aOrderPos/2);
		//int dbMCIndex 	= getMachineIndex(machine);
		//int targetMCIndex = Int(aOrderPos/16);//2 --> each machine have two LP.
		//if((dbMCIndex == targetMCIndex) && (aGridStation == istation))
		if((machine == tarMachine) && (aGridStation == istation))
		{
		//ShowMessage(Format("found %d, %d, %s", [grid_row2, dbMCIndex, machine]));
			String nor_plncnt = frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_NORPLNCNT);	
			String nor_actcnt = frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_NORACTCNT);	
			String osd_plncnt = frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_OSNDPLNCNT);	
			String osd_actcnt = frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_OSNDACTCNT);	

			int inorplncnt = StrToIntDef(nor_plncnt, 0);
			int inoractcnt = StrToIntDef(nor_actcnt, 0);
			int iosdplncnt = StrToIntDef(osd_plncnt, 0);
			int iosdactcnt = StrToIntDef(osd_actcnt, 0);
			
			int pln_sum = inorplncnt + iosdplncnt;
			int act_sum = inoractcnt + iosdactcnt;
		
			if(pln_sum == act_sum)//finish order
			{			
				continue;
			}
			
			String side    	= frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_SHOESSIDE);	
			String sort_key = frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_SORT_KEY);	
			int isort_key   = StrToInt(sort_key);
			int iSide = aOrderPos%2;
			if(((iSide == 0) && (side == "L")) || ((iSide == 1) && (side == "R")))
			{
				//ShowMessage(Format("found %d/%d, %d, %s, %d, %s, %d, %s, %d", [grid_row2, row_cnt2, dbMCIndex, machine, istation, side, iSide, sort_key, imin_sort_key]));
				if(imin_sort_key > isort_key) 
				{
					imin_sort_key = isort_key;
					row_result = grid_row2;
				}
				else
				{
					break;
				}
			}	
		}
	}
	return row_result;
}

//=======================================================================================
int UpdateSOID()
{
	frmScreen1_4.dhGrid2.UpdateStart(1);
    frmScreen1_4.dhGrid2.Clear();
	int iSOIDZeroNum = 0;
	
	int row = frmScreen1_4.dhGrid2.SetAddRow(false);
	frmScreen1_4.dhGrid2.SetCellDataColor2(row, 0, "Machine", false, clBlack, clWhite);
	frmScreen1_4.dhGrid2.SetCellDataColor2(row, 1, frmScreen1_4.cbxMCA1.Text, false, clBlack, clWhite);
	
	int iSOID;
    for(int i=0; i<STATION_NUM; i++)
    {
		iSOID = GetTagValueI(gTagSOID[i]);	
        row = frmScreen1_4.dhGrid2.SetAddRow(false);
		String sStationName = IntToStr(Int(i/2) + 1);
		if(i%2 == 0) sStationName += "L";
		else         sStationName += "R";
        frmScreen1_4.dhGrid2.SetCellData(row, 0, sStationName, false);
		frmScreen1_4.dhGrid2.SetCellData(row, 1, Format("%d", [iSOID]), false);
		
		if(iSOID == 0) iSOIDZeroNum++;
	}
	frmScreen1_4.dhGrid2.UpdateStart(0);    
	
	return iSOIDZeroNum;
}

//=======================================================================================
int getNextOrderRow(String aMachine, int aRow)
{
	String station 	  = frmScreen1.dhGrid1.GetCellData(aRow, COLUMN_STATION);
	String sort_key	  = frmScreen1.dhGrid1.GetCellData(aRow, COLUMN_SORT_KEY);
	String side 	  = frmScreen1.dhGrid1.GetCellData(aRow, COLUMN_SHOESSIDE);
	
	int istation = StrToInt(station) - 1;
	int isort_key = StrToInt(sort_key);
	
	int row_cnt = frmScreen1.dhGrid1.GetRowCount;
	for(int grid_row2=aRow+1; grid_row2<row_cnt; grid_row2++)
	{
		String station2	 = frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_STATION);
		int istation2 = StrToInt(station2) - 1;	
		if(istation != istation2) continue;
		
		String machine  = frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_MACHINE);	
		if(aMachine != machine) continue;
		
		String soid2 	= frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_SO_ID);	
		String sort_key2 = frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_SORT_KEY);	
		String side2 	= frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_SHOESSIDE);	
	
		String nor_plncnt = frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_NORPLNCNT);	
		String nor_actcnt = frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_NORACTCNT);	
		String osd_plncnt = frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_OSNDPLNCNT);	
		String osd_actcnt = frmScreen1.dhGrid1.GetCellData(grid_row2, COLUMN_OSNDACTCNT);	

		int isort_key2 = StrToInt(sort_key2);	
		int inorplncnt = StrToIntDef(nor_plncnt, 0);
		int inoractcnt = StrToIntDef(nor_actcnt, 0);
		int iosdplncnt = StrToIntDef(osd_plncnt, 0);
		int iosdactcnt = StrToIntDef(osd_actcnt, 0);

		int pln_sum = inorplncnt + iosdplncnt;
		int act_sum = inoractcnt + iosdactcnt;
			
		if((isort_key < isort_key2) && (side == side2) && (pln_sum > act_sum))
		{
			SetDebug(Format("Next Order : %d, SO_ID=%s, SORT_Key=%s, Station=%s", [grid_row2, soid2, sort_key2, station2]));	
			return grid_row2;
		}
	}

	return -1;
}


//=======================================================================================
//ready to next order
int checkFinish(int aRow, int aStation, int aAct, int aOSD)
{
	//ShowMessage(Format("check finish, %d, %d, %d", [aStation, aAct, aOSD]));
	if((aAct == 0) && (aOSD == 0)) 
	{
		string sort_key = frmScreen1.dhGrid1.GetCellData(aRow, COLUMN_SORT_KEY);	
		int isort_key = StrToIntDef(sort_key, 0);
		//ShowMessage(Format("row 1, %d, %d, %d, %d", [aStation, gWorkingRow[aStation], aAct,  gWorkingNormal[aStation]]));
		
		gWorkingRow[aStation] = -1;

		TimerGetAct.Enabled = false;
		
		//next order download to LP....(station, current sort key)
		gCurrentStation = aStation;
		gCurrentSortKey = isort_key;

		frmScreen1_2.Show();
		TimerCheck.Enabled = true;  
		
		return 1;
	}
	
	return 0;
}

//=======================================================================================
void SetColorRow(int aRow, TColor aColor)
{
	for(int i=0; i<20; i++)
		frmScreen1.dhGrid1.SetCelldataColor2(aRow, i, frmScreen1.dhGrid1.GetCellData(aRow, i), false, aColor, clBlack);
}

//=======================================================================================
void UpdateOSnDPlnToDB(int soid, int osd_pln)
{
    try
	{
		string namedb 	= "readSQL";
		boolean opend 	= DBConnect(namedb, gSvr_type, gSvr, gPort, gUid, gPwd, gDbname); 
		
		string sqlquery = "UPDATE DATA_SO ";
				sqlquery += Format("SET OSND_PRS_QTY = %d", [osd_pln]);
				sqlquery += Format("WHERE SO_ID = %d", [soid]);

		DBScriptClear(namedb);
        DBScriptSQL(namedb, sqlquery);
		DBScriptExecute(namedb);

		DBDisconnect(namedb, true);
	}
	except	
	{
		ShowMessage(ExceptionMessage);
	}	
}


//=======================================================================================
//count_type 00-normal, 01-os&d
void InsertWorkCountToDB(int soid, int workpln, int workcnt, string zone_cd, string count_type)
{
    try
	{
		string namedb 	= "readSQL";
		string currdate = FormatDateTime("YYYYMMDD", Now());
		string sStart 	= frmScreen1.act_start.Text;
		string sEnd  	= FormatDateTime("YYYY-MM-DD HH:NN:SS" + ".000", Now());
		//string mcid  	= frmScreen1.cbxMC.Text;
		string upd_usr	= "MCA16";
		string sec 	 	= DecodeSec(sStart);	 
			
		boolean opend 	= DBConnect(namedb, gSvr_type, gSvr, gPort, gUid, gPwd, gDbname); 

		//===================================================1/3
		string sqlquery_ser_no = "SELECT MAX(SER_NO) AS SER_NO ";
				sqlquery_ser_no += "FROM DATA_RST ";
				sqlquery_ser_no += Format("WHERE SO_ID = %d ", [soid]);
		DBScriptClear(namedb);
        DBScriptSQL(namedb, sqlquery_ser_no);
		DBScriptExecute(namedb);
		int cnt = DBRecordCount(namedb);
		String ser_no;
		if(cnt > 0) ser_no = DBFieldByName_String(namedb, "SER_NO");
		int iser_no = StrToIntDef(ser_no, -1) + 1;
		
		//===================================================2/3
		string sqlquery = "SELECT SO_ID, VERSION_ID, FACTORY, RESOURCE_CD, ZONE_CD, IPP_LINE_CD, MOLD_ID, MACHINE_CD, STATION_CD, STATION_TYPE ";
				sqlquery += "FROM DATA_SO ";
				sqlquery += Format("WHERE SO_ID='%d'", [soid]);
        DBScriptClear(namedb);
        DBScriptSQL(namedb, sqlquery);
		DBScriptExecute(namedb);

		String s1 = DBFieldByName_String(namedb, "VERSION_ID");
		String s2 = DBFieldByName_String(namedb, "FACTORY");
		String s3 = DBFieldByName_String(namedb, "RESOURCE_CD");
		String s4 = DBFieldByName_String(namedb, "ZONE_CD");
		String s5 = DBFieldByName_String(namedb, "IPP_LINE_CD");
		String s6 = DBFieldByName_String(namedb, "MACHINE_CD");
		String s7 = DBFieldByName_String(namedb, "STATION_CD");
		String s8 = DBFieldByName_String(namedb, "STATION_TYPE");
		String sMoldID = DBFieldByName_String(namedb, "MOLD_ID");
			
		DBLast(namedb);
		
		String sInjector_cd;
		if(s8 == "L") sInjector_cd = "1";
		else          sInjector_cd = "2";
		//===================================================3/3
		string sqlinsert = "INSERT INTO DATA_RST (RST_YMD, SO_ID, VERSION_ID, SER_NO, FACTORY, RESOURCE_CD, MOLD_ID, ";
		sqlinsert += "ZONE_CD, IPP_LINE_CD, MACHINE_CD, STATION_CD, STATION_TYPE, START_DATE, END_DATE, NET_WRK_SEC, ";
		sqlinsert += "PRS_QTY, CNT_QTY, REASON, INJECTOR_CD, REMARK, UPD_USER, UPD_YMD) ";
	    sqlinsert += "VALUES ('" + currdate +"', '" + IntToStr(soid) + "', '" + s1 + "', '" + IntToStr(iser_no) + "', '" + s2 + "', '" + s3 + "', '" + sMoldID + "', '" + s4 + "', ";
		sqlinsert += "'" + s5 + "', '" + s6 + "', '" + s7 + "', '" + s8 + "', " ;
		sqlinsert += "'" + sStart + "', '" + sEnd + "', '" + sec + "', '" + IntToStr(workpln) + "', '" + IntToStr(workcnt) + "', '" + count_type + "', '" + sInjector_cd + "', '', '" + upd_usr + "', '" + sEnd + "')";

        DBScriptClear(namedb);
        DBScriptSQL(namedb, sqlinsert);
		DBScriptExecute(namedb);		
		
		DBDisconnect(namedb, true);
	}
	except	
	{
		ShowMessage(ExceptionMessage);
	}	
}

//=======================================================================================
{
	for(int i=0; i<ALL_ORDERS; i++)
    {
		gWorkingRow[i] = -1;
	}

	gTagNorP[0] = TagLNPln1; 
	gTagNorP[1] = TagRNPln1; 
	gTagNorP[2] = TagLNPln2; 
	gTagNorP[3] = TagRNPln2; 
	gTagNorP[4] = TagLNPln3; 
	gTagNorP[5] = TagRNPln3; 
	gTagNorP[6] = TagLNPln4; 
	gTagNorP[7] = TagRNPln4; 
	gTagNorP[8] = TagLNPln5; //TagLNPln1
	gTagNorP[9] = TagRNPln5; 
	gTagNorP[10] = TagLNPln6; 
	gTagNorP[11] = TagRNPln6; 
	gTagNorP[12] = TagLNPln7; 
	gTagNorP[13] = TagRNPln7; 
	gTagNorP[14] = TagLNPln8; 
	gTagNorP[15] = TagLNPln8; 
	
	gTagNorA[0] = TagLNAct1;
	gTagNorA[1] = TagRNAct1;
	gTagNorA[2] = TagLNAct2;
	gTagNorA[3] = TagRNAct2;
	gTagNorA[4] = TagLNAct3;
	gTagNorA[5] = TagRNAct3;
	gTagNorA[6] = TagLNAct4;
	gTagNorA[7] = TagRNAct4; 
	gTagNorA[8] = TagLNAct5;
	gTagNorA[9] = TagRNAct5;
	gTagNorA[10] = TagLNAct6;
	gTagNorA[11] = TagRNAct6;
	gTagNorA[12] = TagLNAct7;
	gTagNorA[13] = TagRNAct7;
	gTagNorA[14] = TagLNAct8;
	gTagNorA[15] = TagRNAct8;
							 
	gTagOsdA[0] = TagLOAct1;
	gTagOsdA[1] = TagROAct1;
	gTagOsdA[2] = TagLOAct2;
	gTagOsdA[3] = TagROAct2;
	gTagOsdA[4] = TagLOAct3;
	gTagOsdA[5] = TagROAct3;
	gTagOsdA[6] = TagLOAct4;
	gTagOsdA[7] = TagROAct4;
	gTagOsdA[8] = TagLOAct5;
	gTagOsdA[9] = TagROAct5;
	gTagOsdA[10] = TagLOAct6;
	gTagOsdA[11] = TagROAct6;
	gTagOsdA[12] = TagLOAct7;
	gTagOsdA[13] = TagROAct7;
	gTagOsdA[14] = TagLOAct8;
	gTagOsdA[15] = TagROAct8;

	gTagOsdP[0] = TagLOPln1;
	gTagOsdP[1] = TagROPln1;
	gTagOsdP[2] = TagLOPln2;
	gTagOsdP[3] = TagROPln2;
	gTagOsdP[4] = TagLOPln3;
	gTagOsdP[5] = TagROPln3;
	gTagOsdP[6] = TagLOPln4;
	gTagOsdP[7] = TagROPln4;
	gTagOsdP[8] = TagLOPln5;
	gTagOsdP[9] = TagROPln5;
	gTagOsdP[10] = TagLOPln6;
	gTagOsdP[11] = TagROPln6;
	gTagOsdP[12] = TagLOPln7;
	gTagOsdP[13] = TagROPln7;
	gTagOsdP[14] = TagLOPln8;
	gTagOsdP[15] = TagROPln8;

	gTagSOID[0] = TagLSOid1;
    gTagSOID[1] = TagRSOid1;
    gTagSOID[2] = TagLSOid2;
    gTagSOID[3] = TagRSOid2;
    gTagSOID[4] = TagLSOid3;
    gTagSOID[5] = TagRSOid3;
    gTagSOID[6] = TagLSOid4;
    gTagSOID[7] = TagRSOid4;
    gTagSOID[8] = TagLSOid5;
    gTagSOID[9] = TagRSOid5;
    gTagSOID[10] = TagLSOid6;
    gTagSOID[11] = TagRSOid6;
    gTagSOID[12] = TagLSOid7;
    gTagSOID[13] = TagRSOid7;
    gTagSOID[14] = TagLSOid8;
    gTagSOID[15] = TagRSOid8;

/*	gTagMold[0] = TagLSOid1;
    gTagMold[1] = TagRSOid1;
    gTagMold[2] = TagLSOid2;
    gTagMold[3] = TagRSOid2;
    gTagMold[4] = TagLSOid3;
    gTagMold[5] = TagRSOid3;
    gTagMold[6] = TagLSOid4;
    gTagMold[7] = TagRSOid4;
    gTagMold[8] = TagLSOid5;
    gTagMold[9] = TagRSOid5;
    gTagMold[10] = TagLSOid6;
    gTagMold[11] = TagRSOid6;
    gTagMold[12] = TagLSOid7;
    gTagMold[13] = TagRSOid7;
    gTagMold[14] = TagLSOid8;
    gTagMold[15] = TagRSOid8;*/
	
	gTagWrite[0] = WS1;
	gTagWrite[1] = WS2;
	
	gTagTimeWrite[0] = TagLP1Hour;
	gTagTimeWrite[1] = TagLP2Hour;
/*	
	int iTagNorP[STATION_NUM];
	int iTagOsdP[STATION_NUM];

	iTagNorP[0] = TagLNPln1;
	iTagNorP[1] = TagRNPln1;
	iTagNorP[2] = TagLNPln2;
	iTagNorP[3] = TagRNPln2;
	iTagNorP[4] = TagLNPln3;
	iTagNorP[5] = TagRNPln3;
	iTagNorP[6] = TagLNPln4;
	iTagNorP[7] = TagRNPln4;
	iTagNorP[8] = TagLNPln5;
	iTagNorP[9] = TagRNPln5;
	iTagNorP[10] = TagLNPln6;
	iTagNorP[11] = TagRNPln6;
	iTagNorP[12] = TagLNPln7;
	iTagNorP[13] = TagRNPln7;
	iTagNorP[14] = TagLNPln8;
	iTagNorP[15] = TagRNPln8;

	iTagOsdP[0] = TagLOPln1;
	iTagOsdP[1] = TagROPln1;
	iTagOsdP[2] = TagLOPln2;
	iTagOsdP[3] = TagROPln2;
	iTagOsdP[4] = TagLOPln3;
	iTagOsdP[5] = TagROPln3;
	iTagOsdP[6] = TagLOPln4;
	iTagOsdP[7] = TagROPln4;
	iTagOsdP[8] = TagLOPln5;
	iTagOsdP[9] = TagROPln5;
	iTagOsdP[10] = TagLOPln6;
	iTagOsdP[11] = TagROPln6;
	iTagOsdP[12] = TagLOPln7;
	iTagOsdP[13] = TagROPln7;
	iTagOsdP[14] = TagLOPln8;
	iTagOsdP[15] = TagROPln8;*/
}