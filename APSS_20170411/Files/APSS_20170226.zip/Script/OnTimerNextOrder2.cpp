#language C++Script
#include "GlobalScripts.pas", "LPComm.cpp", "GlobalJJ.cpp"

void OnTimerNextOrder2()
{
	
	//TimerGetAct.Enabled = true;
}  

{

}